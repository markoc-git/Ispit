<?php
include "../app/config/config.php"; // Povezivanje na bazu podataka

header('Content-Type: application/json');

// SQL upit za dobijanje ukupne količine proizvoda po kategorijama
$sql = "SELECT c.name AS category_name, SUM(p.quantity) AS total_quantity
        FROM categories c
        LEFT JOIN products p ON c.categories_id = p.category_id
        GROUP BY c.categories_id, c.categories_name
        ORDER BY total_quantity DESC";

$result = $conn->query($sql);

$data = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode($data);
?>
