<?php
include "app/config/config.php"; // Povezivanje na bazu podataka

header('Content-Type: application/json'); // Postavljanje tipa sadržaja na JSON

// SQL upit za dobijanje ukupne količine proizvoda po kategorijama
$sql = "SELECT c.name AS category_name, SUM(p.quantity) AS total_quantity
        FROM categories c
        LEFT JOIN products p ON c.categories_id = p.category_id
        GROUP BY c.categories_id, c.name
        ORDER BY total_quantity DESC";

$result = $conn->query($sql);

$data = []; // Inicijalizacija praznog niza za podatke

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row; // Dodavanje rezultata u niz
    }
}

// Vraćanje JSON podataka
echo json_encode($data);
?>
7