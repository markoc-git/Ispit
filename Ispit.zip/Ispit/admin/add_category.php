<?php
// Uključivanje potrebnih fajlova
include "../app/config/config.php";
include "../app/classes/User.php";
include "../app/classes/Category.php";
include "../inc/header.php";

// Provera da li je korisnik prijavljen i da li je administrator
if (!User::is_logged()) {
    header("Location: login.php");
    exit();
}

$user = new User($conn);
$is_admin = $user->is_admin($_SESSION["user_id"]);

if (!$is_admin) {
    header("Location: ../index.php"); // Ako nije admin, preusmeri ga
    exit();
}

$category = new Category($conn);

// Obrada forme za dodavanje nove kategorije
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_category'])) {
    // Proverite da li je category_name postavljen u POST podacima
    $name = isset($_POST['category_name']) ? $_POST['category_name'] : null;

    // Proveriti da li je uneseno ime kategorije
    if ($name && !empty($name)) {
        $create_result = $category->create($name);

        if ($create_result === true) {
            $_SESSION['message'] = "Kategorija je uspešno dodata.";
            header("Location: index.php"); // Preusmeravanje na stranicu sa kategorijama
            exit();
        } else {
            $_SESSION['message'] = "Greška pri dodavanju kategorije: " . $create_result;
        }
    } else {
        $_SESSION['message'] = "Naziv kategorije je obavezan.";
    }
}
?>

<!-- Prikazivanje poruka -->
<?php if (isset($_SESSION['message'])) { echo "<div class='alert alert-info'>" . $_SESSION['message'] . "</div>"; } ?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Dodaj novu kategoriju</h2>

    <form method="POST" class="bg-light p-4 rounded shadow-sm">
        <div class="mb-3">
            <label for="name" class="form-label">Naziv kategorije:</label>
            <input type="text" id="name" name="category_name" class="form-control" required>
        </div>

        <button type="submit" name="create_category" class="btn btn-primary w-100">Kreiraj kategoriju</button>
    </form>
</div>

<?php include "../inc/footer.php"; ?>
