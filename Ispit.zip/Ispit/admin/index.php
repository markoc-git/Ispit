<?php
include "../app/config/config.php";
include "../app/classes/User.php";
include "../app/classes/Product.php";
include "../inc/header.php";

// Provera da li je korisnik prijavljen
if (!User::is_logged()) {
    header("Location: login.php");  // Ako nije prijavljen, preusmeri ga na login stranicu
    exit();
}

// Kreiranje objekta korisnika
$user = new User($conn);

// Kreiranje objekta za proizvode
$product = new Product($conn, $user);

// Provera da li je korisnik administrator
$is_admin = $user->is_admin($_SESSION["user_id"]);

// Pozivanje funkcije za kategorije sa količinama
$category_data = $product->getCategoriesWithQuantities();

// Pozivanje funkcije za proizvode koji su istekli ili će uskoro isteći
$expiring_data = $product->getExpiredProducts();
?>

<div class="container">
    <h2>Dobrodošli na početnu stranicu</h2>

    <?php if ($is_admin): ?>
        <a href="add_product.php" class="btn btn-primary mb-3">Dodaj novi proizvod</a>
    <?php endif; ?>

    <!-- Prikazivanje proizvoda -->
    <h3 class="mt-5">Lista proizvoda</h3>
    <?php 
        $products = $product->getAllProducts();
        if ($products): 
    ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ime</th>
                    <th>Količina</th>
                    <th>Cena</th>
                    <th>Datum isteka</th>
                    <th>Opis</th>
                    <th>Kategorija</th>
                    <th>Slika</th>
                    <?php if ($is_admin): ?>
                        <th>Akcija</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $prod): ?>
                    <tr>
                        <td><?php echo $prod['product_id']; ?></td>
                        <td><?php echo $prod['product_name']; ?></td>
                        <td><?php echo $prod['quantity']; ?></td>
                        <td><?php echo $prod['price']; ?>$</td>
                        <td><?php echo $prod['expiration_date']; ?></td>
                        <td><?php echo $prod['description']; ?></td>
                        <td><?php echo $prod['category_name']; ?></td>
                        <td>
                            <?php if (!empty($prod['image_url'])): ?>
                                <img src="../<?php echo $prod['image_url']; ?>" alt="Slika proizvoda" style="width: 100px; height: auto;">
                            <?php else: ?>
                                Nema slike
                            <?php endif; ?>
                        </td>
                        <?php if ($is_admin): ?>
                            <td>
                                <form action="delete_product.php" method="POST">
                                    <input type="hidden" name="product_id" value="<?php echo $prod['product_id']; ?>">
                                    <button type="submit" class="btn btn-danger">Obriši</button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nema proizvoda u bazi.</p>
    <?php endif; ?>

    <!-- Statistički grafici -->
    <h3>Statistika</h3>
    <div class="row">
        <div class="col-md-6">
            <h4>Ukupna količina proizvoda po kategorijama</h4>
            <canvas id="categoryChart"></canvas>
        </div>
        <div class="col-md-6">
            <h4>Proizvodi koji su istekli ili će uskoro isteći</h4>
            <canvas id="expiringChart"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Osiguraj da su PHP podaci pravilno prosleđeni u JavaScript
    const categoryData = <?php echo json_encode($category_data); ?>;
    const expiringData = <?php echo json_encode($expiring_data); ?>;

    // Proveri da li su podaci validni za kategorije
    if (categoryData && Array.isArray(categoryData)) {
        const labelsCategory = categoryData.map(item => item.category_name);
        const quantitiesCategory = categoryData.map(item => item.total_quantity);

        const ctxCategory = document.getElementById('categoryChart').getContext('2d');
        new Chart(ctxCategory, {
            type: 'bar',
            data: {
                labels: labelsCategory,
                datasets: [{
                    label: 'Ukupna količina',
                    data: quantitiesCategory,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: { scales: { y: { beginAtZero: true } } }
        });
    } else {
        console.error("Data for category chart is missing or invalid");
    }

    // Proveri da li su podaci validni za proizvode koji ističu
    if (expiringData && Array.isArray(expiringData)) {
        const labelsExpiring = expiringData.map(item => item.product_name);
        const expiringQuantities = expiringData.map(item => item.quantity);

        const ctxExpiring = document.getElementById('expiringChart').getContext('2d');
        new Chart(ctxExpiring, {
            type: 'pie',
            data: {
                labels: labelsExpiring,
                datasets: [{
                    label: 'Proizvodi koji ističu',
                    data: expiringQuantities,
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: { responsive: true }
        });
    } else {
        console.error("Data for expiring chart is missing or invalid");
    }
</script>

</body>
</html>
