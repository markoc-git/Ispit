<?php
include "../app/config/config.php";
include "../app/classes/User.php";
include "../app/classes/Product.php";
include "../inc/header.php";

// Provera da li je korisnik prijavljen i da li je administrator
if (!User::is_logged()) {
    header("Location: login.php");
    exit();
}

$user = new User($conn);
$is_admin = $user->is_admin($_SESSION["user_id"]);

if (!$is_admin) {
    header("Location: ../index.php"); // Ako nije admin, preusmeri ga
    exit();
}

$product = new Product($conn, $user);

// Obrada forme za dodavanje novog proizvoda
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_product'])) {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $expiration_date = $_POST['expiration_date'] ?? null;
    $description = $_POST['description'] ?? null;

    // Provera i upload slike
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = "../move_uploaded_file/";
        $file_name = basename($_FILES['image']['name']);
        $target_file = $upload_dir . $file_name;
    
        // Provera ekstenzije fajla
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (in_array($file_extension, $allowed_extensions)) {
            // Premesti fajl u direktorijum
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Uklanjanje "../" iz putanje pre unosa u bazu
                $image_url = str_replace("../", "", $target_file);
            } else {
                $_SESSION['message'] = "Greška pri upload-u slike.";
            }
        } else {
            $_SESSION['message'] = "Dozvoljene su samo slike (jpg, jpeg, png, gif).";
        }
    }
    

    $create_result = $product->create($name, $quantity, $price, $category_id, $expiration_date, $description, $image_url);
    header("Location: index.php");
}
?>

<div class="container mt-5">
    <h2 class="text-center">Dodaj novi proizvod</h2>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="name">Naziv proizvoda:</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>

            <div class="form-group col-md-6">
                <label for="quantity">Količina:</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="price">Cena:</label>
                <input type="number" class="form-control" id="price" name="price" required>
            </div>

            <div class="form-group col-md-6">
                <label for="category_id">Kategorija:</label>
                <select id="category_id" name="category_id" class="form-control" required>
                    <option value="">Izaberite kategoriju</option>
                    <?php
                    $categories = $product->getCategories();
                    foreach ($categories as $category) {
                        echo "<option value='{$category['categories_id']}'>{$category['category_name']}</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="expiration_date">Datum isteka:</label>
                <input type="date" class="form-control" id="expiration_date" name="expiration_date">
            </div>

            <div class="form-group col-md-6">
                <label for="image">Izaberite sliku:</label>
                <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
            </div>
        </div>

        <div class="form-group">
            <label for="description">Opis:</label>
            <textarea class="form-control" id="description" name="description"></textarea>
        </div>

        <button type="submit" name="create_product" class="btn btn-primary btn-block">Dodaj proizvod</button>
    </form>
</div>

<?php include "../inc/footer.php"; ?>
