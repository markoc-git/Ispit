<?php
include "../app/config/config.php";
include "../app/classes/Product.php";

// Provera da li je korisnik prijavljen i da li je administrator
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kreiranje objekta za proizvod
$product = new Product($conn, null);

// Provera da li je dobavljen ID proizvoda
if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $delete_result = $product->delete($product_id);
    
    if ($delete_result) {
        $_SESSION['message'] = "Proizvod je uspešno obrisan.";
    } else {
        $_SESSION['message'] = "Greška pri brisanju proizvoda.";
    }
}

header("Location: ../index.php");
exit();
