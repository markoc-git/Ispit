-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2025 at 01:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skladiste`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categories_id`, `category_name`) VALUES
(1, 'Racunari\r\n'),
(2, 'Telefoni'),
(8, 'Napajanje'),
(9, 'RAM ');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `price` decimal(10,0) NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `image_url` varchar(255) NOT NULL DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `quantity`, `price`, `expiration_date`, `description`, `category_id`, `created_at`, `updated_at`, `image_url`) VALUES
(11, 'Samsung A20', 2, 200, '2025-01-11', 'Samsung telefon ', 2, '2025-01-10 12:06:27', '2025-01-10 12:06:27', 'move_uploaded_file/Samsung-Galaxy-A20.jpg'),
(14, 'Redmi 13Pro ', 5, 400, '0000-00-00', '', 2, '2025-01-10 12:27:05', '2025-01-10 12:27:05', 'move_uploaded_file/redmi-note-13-pro-5g-6846.png'),
(15, 'Giga 432e', 3, 1000, '0000-00-00', 'Procesor : Intel I5\r\nRam : 16GB', 1, '2025-01-10 12:33:31', '2025-01-10 12:33:31', 'move_uploaded_file/4133.jpg'),
(17, 'Napajanje 650W', 4, 100, '2024-12-30', '', 8, '2025-01-13 00:51:58', '2025-01-13 00:51:58', 'move_uploaded_file/Napajanje.jpg'),
(19, 'Iphone ', 5, 1000, '2025-01-04', 'Iphone Novi ', 2, '2025-01-13 01:18:18', '2025-01-13 01:18:18', 'move_uploaded_file/iphone_13_midnight_pdp_image_position-1a__wwen_1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_feedback das`
--

CREATE TABLE `product_feedback das` (
  `product_feedback_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_stock_location`
--

CREATE TABLE `product_stock_location` (
  `product_stock_location_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,0) NOT NULL,
  `sale_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions das`
--

CREATE TABLE `transactions das` (
  `transactions_id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `transaction_type` enum('dodavanje','uzimanje','','') NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT current_timestamp(),
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `is_admin`, `created_at`, `updated_at`) VALUES
(1, 'Marko', '$2y$10$ejJWrNQMwve9PQs3pZG3E.0zra6Jgoe8z8PzYT/71rDFF0sq70Vpy', 1, '2024-11-19 16:09:36', '2024-11-19 16:09:36'),
(2, 'Caca', '$2y$10$Slex2ldhUcY6bwny0pI75u6v5Ywnf0gyuWCcmDzod5IxyZUAZcl9a', 0, '2025-01-10 11:40:08', '2025-01-10 11:40:08'),
(3, 'Markocar1.', '$2y$10$soJxrfNWb9LF6e6vS4P3CeW0g8ntFzt1PycIrmSVIPQlkUcqjtZam', 1, '2025-01-10 11:40:38', '2025-01-10 11:40:38'),
(4, 'markocerovicdev@gmail.com', '$2y$10$3HVTZ9n2zBCZIPKi9CSP1OYtKnpoDgfjAolKgxqZyG2jSdihiFrnO', 0, '2025-01-12 23:43:04', '2025-01-12 23:43:04'),
(5, 'dasdasdas', '$2y$10$JDGV9FeTtQUUcWWbC8PsFOvZ6R.oiE6qGoevVj/1G9m93GNS.xwjO', 0, '2025-01-13 01:01:58', '2025-01-13 01:01:58'),
(6, 'dasdasdasdasD', '$2y$10$bbE9if4RIQX9QyetK8.bCu34buBIDfsf1VTWfaiWxE5FW0H3G4dbO', 0, '2025-01-13 01:15:33', '2025-01-13 01:15:33');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_locations`
--

CREATE TABLE `warehouse_locations` (
  `warehouse_locations_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_feedback das`
--
ALTER TABLE `product_feedback das`
  ADD PRIMARY KEY (`product_feedback_id`);

--
-- Indexes for table `product_stock_location`
--
ALTER TABLE `product_stock_location`
  ADD PRIMARY KEY (`product_stock_location_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sale_id`);

--
-- Indexes for table `transactions das`
--
ALTER TABLE `transactions das`
  ADD PRIMARY KEY (`transactions_id`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `warehouse_locations`
--
ALTER TABLE `warehouse_locations`
  ADD PRIMARY KEY (`warehouse_locations_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categories_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product_feedback das`
--
ALTER TABLE `product_feedback das`
  MODIFY `product_feedback_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_stock_location`
--
ALTER TABLE `product_stock_location`
  MODIFY `product_stock_location_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions das`
--
ALTER TABLE `transactions das`
  MODIFY `transactions_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `warehouse_locations`
--
ALTER TABLE `warehouse_locations`
  MODIFY `warehouse_locations_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
