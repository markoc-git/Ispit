<?php

class Product {
    protected $conn;
    protected $user;

    // Konstruktor za povezivanje sa bazom i korisnika (da bi se proverila administratorska prava)
    public function __construct($conn, $user) {
        $this->conn = $conn;
        $this->user = $user;
    }

    // Kreiranje novog proizvoda (samo za administratore)
    public function create($name, $quantity, $price, $category_id, $expiration_date = null, $description = null, $image_url = null) {
        if (!$this->user->is_admin($_SESSION["user_id"])) {
            return "Nemate administrativne privilegije.";
        }
    
        // SQL query za ubacivanje proizvoda u bazu, uključujući image_url
        $sql = "INSERT INTO products (product_name, quantity, price, category_id, expiration_date, description, image_url, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
    
        // Priprema upita
        $stmt = $this->conn->prepare($sql);
    
        if (!$stmt) {
            return false;
        }
    
        // Povezivanje parametara: name, quantity, price, category_id, expiration_date, description, image_url
        $stmt->bind_param("siidsss", $name, $quantity, $price, $category_id, $expiration_date, $description, $image_url);
    
        // Izvršenje upita
        $result = $stmt->execute();
    
        // Provera uspešnosti
        if ($result) {
            return true;
        }
    
        return false;
    }
    
    // Dohvatanje svih proizvoda (dostupno svima)
    public function getAllProducts($search = '', $category_id = '', $min_price = '', $max_price = '') {
        $sql = "SELECT p.product_id, p.product_name AS product_name, p.quantity, p.price, p.expiration_date, 
                       p.description, p.image_url, c.category_name AS category_name
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.categories_id
                WHERE 1";
    
        if ($search) {
            $sql .= " AND p.product_name LIKE ?";
        }
        if ($category_id) {
            $sql .= " AND p.category_id = ?";
        }
        if ($min_price) {
            $sql .= " AND p.price >= ?";
        }
        if ($max_price) {
            $sql .= " AND p.price <= ?";
        }
    
        $stmt = $this->conn->prepare($sql);
        $types = '';
        $params = [];
    
        if ($search) {
            $types .= 's';
            $params[] = '%' . $search . '%';
        }
        if ($category_id) {
            $types .= 'i';
            $params[] = $category_id;
        }
        if ($min_price) {
            $types .= 'd';
            $params[] = $min_price;
        }
        if ($max_price) {
            $types .= 'd';
            $params[] = $max_price;
        }
    
        if ($types) {
            $stmt->bind_param($types, ...$params);
        }
    
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            $products = [];
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
            return $products;
        }
    
        return false;
    }
    
    
    
    // Dohvatanje svih kategorija (dostupno svima)
    public function getCategories() {
        $sql = "SELECT * FROM categories";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            $categories = [];
            while ($row = $result->fetch_assoc()) {
                $categories[] = $row;
            }
            return $categories;
        }

        return false;
    }

    // Brisanje proizvoda (samo za administratore)
    public function delete($product_id) {
        $sql = "DELETE FROM products WHERE product_id = ?";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return false;
        }

        $stmt->bind_param("i", $product_id);
        $result = $stmt->execute();
        return $result;
    }

    // U klasi Product.php
    public function getFilteredProducts($filters = [])
{
    $sql = "SELECT p.product_id, 
                   p.product_name as product_name, 
                   p.price, 
                   p.quantity, 
                   p.description, 
                   p.image_url, 
                   c.category_name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.categories_id
            WHERE 1=1"; // Osnovni upit
    
    $params = [];
    $types = '';

    // Dodavanje filtera u SQL upit
    if (!empty($filters['category_id'])) {
        $sql .= " AND p.category_id = ?";
        $params[] = $filters['category_id'];
        $types .= 'i';
    }

    if (!empty($filters['price_min'])) {
        $sql .= " AND p.price >= ?";
        $params[] = $filters['price_min'];
        $types .= 'd';
    }

    if (!empty($filters['price_max'])) {
        $sql .= " AND p.price <= ?";
        $params[] = $filters['price_max'];
        $types .= 'd';
    }

    $stmt = $this->conn->prepare($sql);

    // Povezivanje parametara ako ih ima
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    // Provera rezultata
    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    return false; // Nema proizvoda koji odgovaraju filterima
}


public function getCategoriesWithQuantities() {
    // SQL upit koji spaja tabele products i categories preko category_id i sabira količine
    $query = "
        SELECT c.category_name, SUM(p.quantity) AS total_quantity
        FROM products p
        INNER JOIN categories c ON p.category_id = c.categories_id  -- koristi categories_id u tabeli categories
        GROUP BY c.category_name
        ORDER BY total_quantity DESC
    ";

    $result = $this->conn->query($query);

    // Proveravamo da li je upit uspešno izvršen i vraćamo podatke
    if ($result) {
        $category_data = [];
        while ($row = $result->fetch_assoc()) {
            $category_data[] = [
                'category_name' => $row['category_name'],
                'total_quantity' => $row['total_quantity']
            ];
        }
        return $category_data;
    } else {
        return [];
    }
}

public function getExpiringSoonProducts($days = 30) {
    $query = "
        SELECT product_name, expiration_date, quantity
        FROM products
        WHERE expiration_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL $days DAY)  -- Proizvodi kojima ističe rok za $days dana
    ";

    $result = $this->conn->query($query);

    if ($result) {
        $expiring_soon_data = [];
        while ($row = $result->fetch_assoc()) {
            $expiring_soon_data[] = [
                'product_name' => $row['product_name'],
                'expiration_date' => $row['expiration_date'],
                'quantity' => $row['quantity']
            ];
        }
        return $expiring_soon_data;
    } else {
        return [];
    }
}
public function getExpiredProducts() {
    $query = "
        SELECT product_name, expiration_date, quantity
        FROM products
        WHERE expiration_date < CURDATE()  -- Proizvodi čiji je datum isteka prošao
    ";

    $result = $this->conn->query($query);

    if ($result) {
        $expired_data = [];
        while ($row = $result->fetch_assoc()) {
            $expired_data[] = [
                'product_name' => $row['product_name'],
                'expiration_date' => $row['expiration_date'],
                'quantity' => $row['quantity']
            ];
        }
        return $expired_data;
    } else {
        return [];
    }
}


}

?>
