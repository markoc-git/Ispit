<?php
class Category {
    protected $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Kreiranje nove kategorije
public function create($name) {
    // Provera da li kategorija već postoji
    $sql_check = "SELECT * FROM categories WHERE category_name = ?";  // Koristite tačan naziv kolone
    $stmt_check = $this->conn->prepare($sql_check);
    $stmt_check->bind_param("s", $name);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows > 0) {
        return "Kategorija sa tim imenom već postoji.";
    }

    // Unos nove kategorije
    $sql = "INSERT INTO categories (category_name) VALUES (?)";  // Koristite tačan naziv kolone
    $stmt = $this->conn->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("s", $name);
    $result = $stmt->execute();

    if ($result) {
        return true;
    }

    return false;
}

    
}
?>
