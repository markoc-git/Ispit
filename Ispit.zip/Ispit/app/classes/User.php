<?php
class User {
    protected $conn;

    // Konstruktor za povezivanje sa bazom
    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Kreiranje novog korisnika
    public function create($username, $password, $is_admin = 0) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Proveri da li korisničko ime već postoji
        $sql_check = "SELECT * FROM users WHERE username = ?";
        $stmt_check = $this->conn->prepare($sql_check);
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        $result = $stmt_check->get_result();

        if ($result->num_rows > 0) {
            return "Korisničko ime već postoji.";
        }

        // Unos novog korisnika
        $sql = "INSERT INTO users (username, password, is_admin, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            return false;
        }

        $stmt->bind_param("ssi", $username, $hashed_password, $is_admin);
        $result = $stmt->execute();

        if ($result) {
            return true;
        }

        return false;
    }

    // Prijava korisnika
    public function login($username, $password) {
        $sql = "SELECT user_id, password FROM users WHERE username = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            // Provera lozinke
            if (password_verify($password, $user["password"])) {
                $_SESSION["user_id"] = $user["user_id"]; // Čuvanje korisničkog ID-a u sesiji
                return true;
            }
        }

        return false;
    }

    // Provera da li je korisnik prijavljen
    public static function is_logged() {
        return isset($_SESSION["user_id"]);
    }

    // Odjava korisnika
    public function logout() {
        unset($_SESSION["user_id"]);
    }

    // Provera administratorskih privilegija
    public function is_admin($user_id) {
        $stmt = $this->conn->prepare("SELECT is_admin FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            return $user['is_admin'] == 1; // Vraća true ako je korisnik admin
        }

        return false;
    }
}
?>
