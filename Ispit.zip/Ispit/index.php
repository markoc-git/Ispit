<?php
include "app/config/config.php";
include "app/classes/User.php";
include "app/classes/Product.php";
include "inc/header.php";

// Provera da li je korisnik prijavljen
if (!User::is_logged()) {
    header("Location: login.php");  // Ako nije prijavljen, preusmeri ga na login stranicu
    exit();
}

// Kreiranje objekta korisnika
$user = new User($conn);

// Kreiranje objekta za proizvode
$product = new Product($conn, $user);

// Provera da li je korisnik administrator
$is_admin = $user->is_admin($_SESSION["user_id"]);

// Filtriranje proizvoda prema postavljenim parametrima
$filters = [];
if (isset($_POST['category_filter'])) {
    $filters['category_id'] = $_POST['category_filter'];
}
if (isset($_POST['price_min'])) {
    $filters['price_min'] = $_POST['price_min'];
}
if (isset($_POST['price_max'])) {
    $filters['price_max'] = $_POST['price_max'];
}

// Dobijanje filtriranih proizvoda
$products = $product->getFilteredProducts($filters);
?>

<div class="container">
    <h2>Lista proizvoda</h2>

    <div class="container">
    <h2>Lista proizvoda</h2>

    <!-- Filteri -->
    <div class="row mb-4">
        <form method="POST" class="d-flex justify-content-start w-100">
            <div class="form-group mr-3">
                <label for="category_filter">Kategorija:</label>
                <select id="category_filter" name="category_filter" class="form-control">
                    <option value="">Izaberite kategoriju</option>
                    <?php
                    // Prikazivanje svih kategorija
                    $categories = $product->getCategories();
                    foreach ($categories as $category) {
                        echo "<option value='{$category['categories_id']}'>{$category['category_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mr-3">
                <label for="price_min">Minimalna cena:</label>
                <input type="number" min="0" id="price_min" name="price_min" class="form-control" placeholder="Minimalna cena">
            </div>
            <div class="form-group mr-3">
                <label for="price_max">Maksimalna cena:</label>
                <input type="number" min="0" id="price_max" name="price_max" class="form-control" placeholder="Maksimalna cena">
            </div>

            <button type="submit" class="btn btn-primary mt-4">Filtriraj</button>
        </form>
    </div>




    <!-- Grid dizajn za proizvode -->
    <div class="row">
        <?php if ($products): ?>
            <?php foreach ($products as $prod): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img height="350px" width="200px" src="<?php  echo $prod['image_url'] ? $prod['image_url'] : 'default_image.jpg'; ?>" class="card-img-top" alt="Slika proizvoda" >
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $prod['product_name']; ?></h5>
                            <p class="card-text">Cena: <?php echo $prod['price']; ?>$</p>
                            <p class="card-text">Količina: <?php echo $prod['quantity']; ?></p>
                            <p class="card-text">Opis: <?php echo $prod['description']; ?></p>
                            <p class="card-text">Kategorija: <?php echo $prod['category_name']; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="col-12">Nema proizvoda koji odgovaraju vašem filteru.</p>
        <?php endif; ?>
    </div>
</div>

<?php include "inc/footer.php"; ?>
