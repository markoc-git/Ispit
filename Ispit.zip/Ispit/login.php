<?php

// Povezivanje sa bazom
require_once "app/config/config.php";  // Povezivanje sa bazom
require_once "app/classes/User.php";    // Uključivanje klase User
require_once "inc/header.php";

$user = new User($conn);    // Instanciranje klase User
if (User::is_logged()) {
    header("Location: index.php");  // Ako nije prijavljen, preusmeri ga na login stranicu
    exit();
}

// Obrada zahteva za login
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    $result = $user->login($username, $password);

    if ($result) {
        header("Location: index.php");  // Redirektuj korisnika na stranicu nakon prijave
        exit();
    } else {
        $message = "Pogrešno korisničko ime ili lozinka.";
    }
}
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prijava</title>
    <!-- Uključivanje Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEJx3N+3tkvW3p4F+U2DYbMuE48fwHe62FgV4dV1FzG3T6JwMknUKwEQRvZRo" crossorigin="anonymous">
    <!-- Dodatni stilovi za poboljšanje dizajna -->
    <style>
        body {
            background: linear-gradient(135deg, #6e7dff, #00bcd4); /* Plavi gradijent */
            font-family: 'Roboto', sans-serif;
        }
        .container {
            height: 100vh;
        }
        .card {
            border-radius: 15px;
            overflow: hidden;
        }
        .card-body {
            padding: 2rem;
        }
        .card-header {
            background: #4e73df;
            color: white;
            font-size: 24px;
            text-align: center;
            padding: 1rem;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .btn-primary {
            background-color: #4e73df;
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-size: 16px;
            width: 100%;
        }
        .btn-primary:hover {
            background-color: #375a99;
        }
        .alert {
            text-align: center;
        }
        .text-center a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        .text-center a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center">
        <div class="card shadow-lg" style="max-width: 400px; width: 100%;">
            <div class="card-header">
                <h3>Prijava na sistem</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Korisničko ime</label>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Lozinka</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Prijavi se</button>
                </form>
                <div class="text-center mt-3">
                    <a href="register.php">Nemate nalog? Registrujte se.</a>
                </div>
                <?php if (!empty($message)): ?>
                    <div class="alert alert-danger mt-3"><?php echo $message; ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Uključivanje Bootstrap JS (za odgovarajuće interakcije, npr. modali, dropdowns, itd.) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0M5Q6DL3l67ePXT1s0jeql0LlMjgUb1OaYsgUwO1b4ZIbH8J" crossorigin="anonymous"></script>
</body>
</html>

<?php require_once "inc/footer.php"; ?>
