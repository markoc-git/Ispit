<?php
include "app/config/config.php"; // Povezivanje na bazu podataka

header('Content-Type: application/json'); // Postavljanje tipa sadržaja na JSON

// SQL upit za dobijanje najprodavanijih proizvoda
$sql = "SELECT p.name AS product_name, SUM(o.quantity) AS total_sold
        FROM products p
        INNER JOIN orders o ON p.product_id = o.product_id
        GROUP BY p.product_id, p.name
        ORDER BY total_sold DESC
        LIMIT 10"; // Prikazuje top 10 najprodavanijih proizvoda

$result = $conn->query($sql);

$data = []; // Inicijalizacija praznog niza za podatke

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row; // Dodavanje rezultata u niz
    }
}

// Vraćanje JSON podataka
echo json_encode($data);
?>
        