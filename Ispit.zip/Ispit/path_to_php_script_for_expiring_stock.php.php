<?php
include "app/config/config.php"; // Povezivanje na bazu podataka

header('Content-Type: application/json'); // Postavljanje tipa sadržaja na JSON

// SQL upit za dobijanje zaliha koje uskoro ističu
$sql = "SELECT p.name AS product_name, p.quantity, p.expiration_date
        FROM products p
        WHERE p.expiration_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
        ORDER BY p.expiration_date ASC";

$result = $conn->query($sql);

$data = []; // Inicijalizacija praznog niza za podatke

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row; // Dodavanje rezultata u niz
    }
}

// Vraćanje JSON podataka
echo json_encode($data);
?>
